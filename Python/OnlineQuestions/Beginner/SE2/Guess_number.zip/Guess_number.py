import random

def user_answer():
    return input()

def pc_guess_value(num1):
    range_list = sorted(random.sample(range(num1), num1))
    range_list = range_list[1:]
    pc_guess = random.choice(range_list)
    print(pc_guess)
    return pc_guess,range_list

if __name__ == '__main__':
    count = 0
    value,List_value = pc_guess_value(100)
    user = user_answer()

    while user !='d':
        if user =='k':
            List_value = List_value[:List_value.index(value)]
            value = random.choice(List_value)
        elif user =='b':
            List_value = List_value[List_value.index(value):]
            value = random.choice(List_value)
        print(value)
        user=user_answer()


